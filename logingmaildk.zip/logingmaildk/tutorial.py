#================================#
#======DRAGON`KILLERÎ¾=======#
#====ID LINE : dkdkbot=====#
#====wa : 082197839026 ====#
#================================#

import linepy
from linepy import *
from akad.ttypes import *
from datetime import datetime
import pytz, pafy, null, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, codecs, tweepy, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from googletrans import Translator
import youtube_dl
from time import sleep
from zalgo_text import zalgo
from threading import Thread,Event
import wikipedia as wiki
requests.packages.urllib3.disable_warnings()
from tmp.Instagram import InstagramScraper
from Naked.toolshed.shell import execute_js 
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest


botStart = time.time()
msg_dict = {}
msg_dict1 = {}

cl = LINE("akungmailkalian.com","sandi gmailmu")
cl.log("Auth Token : " + str(cl.authToken))
cl.log("Timeline Token : " + str(cl.tl.channelAccessToken))
clientMid = cl.profile.mid
clientMID = cl.profile.mid
#==============email=======================
creator = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
owner = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
admin = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
staff = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]  

clientProfile = cl.getProfile()
myBOG = cl.profile.mid
clientSettings = cl.getSettings()
oepoll = OEPoll(cl)
mid = cl.getProfile().mid

KAC = [cl]
ABC = [cl]
Bots = [mid]
Bots = [myBOG]
admin = [mid]
owner = [mid]
Saints = admin + owner + staff
Dkbots = creator + owner + admin + staff + Bots




while True:
  try:
      Ops = cl.poll.fetchOperations(cl.revision, 50)
      for op in Ops:
        if op.type != 0:
          cl.revision = max(cl.revision, op.revision)
          bot(op)
  except Exception as E:
    E = str(E)
    if "reason=None" in E:
      print (E)
      time.sleep(60)
      restart_program()