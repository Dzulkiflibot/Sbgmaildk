#================================#
#======DRAGON`KILLERÎ¾=======#
#====ID LINE : dkdkbot=====#
#====wa : 082197839026 ====#
#================================#

import linepy
from linepy import *
from akad.ttypes import *
from datetime import datetime
import pytz, pafy, null, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, codecs, tweepy, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from googletrans import Translator
import youtube_dl
from time import sleep
from zalgo_text import zalgo
from threading import Thread,Event
import wikipedia as wiki
requests.packages.urllib3.disable_warnings()
from tmp.Instagram import InstagramScraper
from Naked.toolshed.shell import execute_js 
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest


botStart = time.time()
msg_dict = {}
msg_dict1 = {}

cl = LINE("akungmailkalian.com","sandi gmailmu")
cl.log("Auth Token : " + str(cl.authToken))
cl.log("Timeline Token : " + str(cl.tl.channelAccessToken))
clientMid = cl.profile.mid
clientMID = cl.profile.mid
#==============email=======================
creator = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
owner = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
admin = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
staff = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]  

clientProfile = cl.getProfile()
myBOG = cl.profile.mid
clientSettings = cl.getSettings()
oepoll = OEPoll(cl)
mid = cl.getProfile().mid

KAC = [cl]
ABC = [cl]
Bots = [mid]
Bots = [myBOG]
admin = [mid]
owner = [mid]
Saints = admin + owner + staff
Dkbots = creator + owner + admin + staff + Bots


wait = {
    "chatbot": True,
      }  
    
#============Chatbots================#
                        elif cmd == "chatbot on" or text.lower() == 'chatbots on':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["chatbot"] = True
                                cl.sendMessage(msg.to,"✔ AutoChat Actived")
                                
                        elif cmd == "chatbot off" or text.lower() == 'chatbots off':
                          if wait["selfbot"] == True:
                            if msg._from in admin:
                                wait["chatbot"] = False
                                cl.sendMessage(msg.to," ↘ AutoChat 🚫 nonaktived")
                        
                        elif cmd == 'sepi':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Hooh gara2 kk sih gak mandi (¬_¬)")
                               
                        elif cmd == 'naik':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Moh ah takut di modusin (¬_¬)")

                        elif cmd == 'nah':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Nah neh noh ¯\_(ツ)_/¯ ")                               
                               
                        elif cmd == 'siang':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Iya kk Mat siang mat aktivitas (￣へ￣)") 

                        elif cmd == 'malam':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Iya malam k waktunya bikin ╮(╯▽╰)╭")
                               
                        elif cmd == 'sp':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to," 🔀 Internet gratisan ¯\_(ツ)_/¯")
                               cl.sendMessage(to,"↘0.005076800537109375 Perdetik")
                               
                        elif cmd == 'assalamualaikum':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to," Waalaikumsalam ")
                               cl.sendMessage(to,"Σ(O_O；)")

                        elif cmd == 'waalaikumsalam':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to," Moga yg jwb salam jodoh nya banyak ")
                               cl.sendMessage(to,"╮(╯▽╰)╭ ")

                        elif cmd == 'typo':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to," Tenggelamkan ae yg Typo¯\_(ツ)_/¯")
                               cl.sendMessage(to,"")                               
                             
                        elif cmd == 'kuy':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to," Kemana k ¯\_(ツ)_/¯")
       
                        elif cmd == 'pagi':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Pagi juga kk Mandi gih biar gak jones terus ヽ(｀⌒´)ノ")
                               
                        elif cmd == 'halo':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Halo juga kk apa kabar ?Σ(⊙▽⊙) ")
       
                        elif cmd == 'me':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"ma me ma me ae memek -_-")       
                               
                        elif cmd == 'oke':
                            if wait["chatbot"] == True:
                               cl.sendMessage(to,"Oke aja deh gue daripada bonyok (╥_╥)")
#===========COMMAND BLACKLIST============#

    except Exception as error:
        print (error)



while True:
  try:
      Ops = cl.poll.fetchOperations(cl.revision, 50)
      for op in Ops:
        if op.type != 0:
          cl.revision = max(cl.revision, op.revision)
          bot(op)
  except Exception as E:
    E = str(E)
    if "reason=None" in E:
      print (E)
      time.sleep(60)
      restart_program()