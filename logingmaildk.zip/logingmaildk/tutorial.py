#================================#
#======DRAGON`KILLERÎ¾=======#
#====ID LINE : dkdkbot=====#
#====wa : 082197839026 ====#
#================================#

import linepy
from linepy import *
from akad.ttypes import *
from datetime import datetime
import pytz, pafy, null, time, asyncio, random, multiprocessing, timeit, sys, json, ctypes, codecs, tweepy, threading, glob, re, ast, six, os, subprocess, wikipedia, atexit, urllib, urllib.parse, urllib3, string, tempfile, shutil, unicodedata
from humanfriendly import format_timespan, format_size, format_number, format_length
import html5lib
import requests,json,urllib3
from random import randint
from bs4 import BeautifulSoup
from googletrans import Translator
import youtube_dl
from time import sleep
from zalgo_text import zalgo
from threading import Thread,Event
import wikipedia as wiki
requests.packages.urllib3.disable_warnings()
from tmp.Instagram import InstagramScraper
from Naked.toolshed.shell import execute_js 
from liff.ttypes import LiffChatContext, LiffContext, LiffSquareChatContext, LiffNoneContext, LiffViewRequest


botStart = time.time()
msg_dict = {}
msg_dict1 = {}

cl = LINE("akungmailkalian.com","sandi gmailmu")
cl.log("Auth Token : " + str(cl.authToken))
cl.log("Timeline Token : " + str(cl.tl.channelAccessToken))
clientMid = cl.profile.mid
clientMID = cl.profile.mid
#==============email=======================
creator = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
owner = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
admin = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]
staff = ["u239d562d314c3b53b6214231c1957ca9","ucea4db871e2f6b401ac278f6999ccf58"]  

clientProfile = cl.getProfile()
myBOG = cl.profile.mid
clientSettings = cl.getSettings()
oepoll = OEPoll(cl)
mid = cl.getProfile().mid

KAC = [cl]
ABC = [cl]
Bots = [mid]
Bots = [myBOG]
admin = [mid]
owner = [mid]
Saints = admin + owner + staff
Dkbots = creator + owner + admin + staff + Bots

    except Exception as error:
        logError(error)


while True:
    try:
        ops = oepoll.singleTrace(count=50)
        if ops is not None:
            for op in ops:
               # bot(op)
                # Don't remove this line, if you wan't get error soon!
                oepoll.setRevision(op.revision)
                thread1 = threading.Thread(target=lineBot, args=(op,))#self.OpInterrupt[op.type], args=(op,)
                #thread1.daemon = True
                thread1.start()
                thread1.join()
    except Exception as e:
        pass
#==============kepo2305===========#
print ("===========[Login Bot Kepo Sukses]==========")
